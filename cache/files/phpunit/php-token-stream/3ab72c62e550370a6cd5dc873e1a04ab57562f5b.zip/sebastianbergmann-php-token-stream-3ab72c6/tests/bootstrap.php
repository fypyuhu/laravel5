<?php
require __DIR__ . '/../vendor/autoload.php';

define(
    'TEST_FILES_PATH',
    __DIR__ . DIRECTORY_SEPARATOR . '_fixture' . DIRECTORY_SEPARATOR
);
